/*!
 * jVectorMap version 2.0.5
 *
 * Copyright 2011-2014, Kirill Lebedev
 * Licensed under the MIT license.
 *
 * https://github.com/bjornd/jvectormap
 */
!function(a,b){"object"==typeof exports&&"undefined"!=typeof module?module.exports=b():"function"==typeof define&&define.amd?define(b):a.jvm=b()}(this,function(){"use strict";var a=function(){function a(a){this.defaultWidth=0,this.defaultHeight=0,this.color="#C8EEFF",this.backgroundColor="#FFFFFF",this.container=null,this.regionNameElement=null,this.map=null,this.mapObject=null,this.mapData=null,this.container=document.createElement("div"),this.container.className="jvm-container",a.appendChild(this.container),this.container.style.width=a.style.width||this.defaultWidth+"px",this.container.style.height=a.style.height||this.defaultHeight+"px",a.style.width="",a.style.height="",this.setBackgroundColor(a.backgroundColor)}return a.prototype.setBackgroundColor=function(a){this.container.style.backgroundColor=a},a.prototype.setSize=function(a,b){this.width=a,this.height=b,this.container.style.width=a+"px",this.container.style.height=b+"px",this.map&&this.map.resize()},a.prototype.getSize=function(){return{width:this.width,height:this.height}},a.prototype.getContainer=function(){return this.container},a}();return a}); 