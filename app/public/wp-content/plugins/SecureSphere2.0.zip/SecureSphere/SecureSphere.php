<?php
/*
Plugin Name: SecureSphere
Description: WordPress security monitoring plugin for MSSP
Version: 2.0
Author: FRENZY
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define constants
define('SECUREPRESS_VERSION', '2.0');
define('SECUREPRESS_LOCAL_LOG', WP_CONTENT_DIR . '/securepress-local.log');
define('SECUREPRESS_BUFFER_SIZE', 50); // Number of events to buffer before sending
define('SECUREPRESS_SEND_INTERVAL', 300); // Send logs every 5 minutes

class SecurePressClient {
    
    private static $instance = null;
    private $log_buffer = [];
    private $site_id;
    private $api_key;
    private $monitoring_server;
    private $failed_logins = [];
    private $options;
    
    private $continent_countries = [
        'asia' => ['AF', 'AM', 'AZ', 'BH', 'BD', 'BT', 'BN', 'KH', 'CN', 'CY', 'GE', 'HK', 'IN', 'ID', 'IR', 'IQ', 'IL', 'JP', 'JO', 'KZ', 'KW', 'KG', 'LA', 'LB', 'MO', 'MY', 'MV', 'MN', 'MM', 'NP', 'OM', 'PK', 'PS', 'PH', 'QA', 'SA', 'SG', 'KR', 'LK', 'SY', 'TW', 'TJ', 'TH', 'TL', 'TR', 'TM', 'AE', 'UZ', 'VN', 'YE'],
        'europe' => ['AL', 'AD', 'AT', 'BY', 'BE', 'BA', 'BG', 'HR', 'CZ', 'DK', 'EE', 'FO', 'FI', 'FR', 'DE', 'GI', 'GR', 'HU', 'IS', 'IE', 'IT', 'LV', 'LI', 'LT', 'LU', 'MT', 'MD', 'MC', 'ME', 'NL', 'NO', 'PL', 'PT', 'RO', 'RU', 'SM', 'RS', 'SK', 'SI', 'ES', 'SE', 'CH', 'UA', 'GB', 'VA'],
        'africa' => ['DZ', 'AO', 'BJ', 'BW', 'BF', 'BI', 'CM', 'CV', 'CF', 'TD', 'KM', 'CG', 'CD', 'CI', 'DJ', 'EG', 'GQ', 'ER', 'ET', 'GA', 'GM', 'GH', 'GN', 'GW', 'KE', 'LS', 'LR', 'LY', 'MG', 'MW', 'ML', 'MR', 'MU', 'MA', 'MZ', 'NA', 'NE', 'NG', 'RW', 'ST', 'SN', 'SC', 'SL', 'SO', 'ZA', 'SS', 'SD', 'SZ', 'TZ', 'TG', 'TN', 'UG', 'ZM', 'ZW'],
        'north-america' => ['AI', 'AG', 'AW', 'BS', 'BB', 'BZ', 'BM', 'CA', 'KY', 'CR', 'CU', 'DM', 'DO', 'SV', 'GL', 'GD', 'GP', 'GT', 'HT', 'HN', 'JM', 'MQ', 'MX', 'MS', 'NI', 'PA', 'PR', 'BL', 'KN', 'LC', 'MF', 'PM', 'VC', 'TT', 'TC', 'US', 'VG', 'VI'],
        'south-america' => ['AR', 'BO', 'BR', 'CL', 'CO', 'EC', 'FK', 'GF', 'GY', 'PE', 'PY', 'SR', 'UY', 'VE'],
        'oceania' => ['AS', 'AU', 'CK', 'FJ', 'PF', 'GU', 'KI', 'MH', 'FM', 'NR', 'NC', 'NZ', 'NU', 'NF', 'MP', 'PW', 'PG', 'PN', 'WS', 'SB', 'TK', 'TO', 'TV', 'VU', 'WF']
    ];
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        $this->options = get_option('securepress_options', [
            'api_key' => '',
            'server_url' => '',
            'send_interval' => 300,
            'blocked_countries' => []
        ]);

        add_action('init', [$this, 'init']);
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        
        // Schedule log transmission
        add_action('securepress_send_logs', [$this, 'send_buffered_logs']);
        add_action('securepress_integrity_check', [$this, 'check_integrity']);
        add_action('securepress_heartbeat', [$this, 'send_heartbeat']);
        
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);
        
        // Send logs immediately for critical events
        add_action('shutdown', [$this, 'send_critical_logs']);
        
        // Add AJAX handlers for geo-blocking
        add_action('wp_ajax_securepress_update_country_status', [$this, 'ajax_update_country_status']);
        add_action('wp_ajax_securepress_block_continent', [$this, 'ajax_block_continent']);
        add_action('wp_ajax_securepress_unblock_continent', [$this, 'ajax_unblock_continent']);
    }
    
    public function enqueue_scripts($hook) {
        if ($hook !== 'settings_page_securepress-mssp') {
            return;
        }

        wp_enqueue_style('securepress-admin', plugins_url('assets/css/admin.css', __FILE__));
        wp_enqueue_style('jvectormap', plugins_url('assets/css/jquery-jvectormap.css', __FILE__));
        wp_enqueue_script('jquery');
        wp_enqueue_script('jvectormap', plugins_url('assets/js/jquery-jvectormap.min.js', __FILE__), ['jquery']);
        wp_enqueue_script('world-mill', plugins_url('assets/js/world-mill.js', __FILE__), ['jquery', 'jvectormap']);

        wp_add_inline_script('world-mill', '
            jQuery(document).ready(function($) {
                var blockedCountries = ' . json_encode($this->options['blocked_countries']) . ';
                
                $("#world-map").vectorMap({
                    map: "world_mill",
                    backgroundColor: "#ffffff",
                    regionStyle: {
                        initial: {
                            fill: "#4CAF50",
                            stroke: "#ffffff",
                            "stroke-width": 1
                        }
                    },
                    onRegionClick: function(event, code) {
                        var isBlocked = blockedCountries.includes(code);
                        if (isBlocked) {
                            blockedCountries = blockedCountries.filter(function(country) {
                                return country !== code;
                            });
                            $(this).vectorMap("set", "colors", code, "#4CAF50");
                        } else {
                            blockedCountries.push(code);
                            $(this).vectorMap("set", "colors", code, "#f44336");
                        }
                        
                        $.post(ajaxurl, {
                            action: "securepress_update_country_status",
                            country: code,
                            blocked: !isBlocked,
                            nonce: "' . wp_create_nonce('securepress_update_country') . '"
                        });
                    }
                });

                // Set initial colors for blocked countries
                blockedCountries.forEach(function(code) {
                    $("#world-map").vectorMap("set", "colors", code, "#f44336");
                });

                // Tab switching
                $(".nav-tab").on("click", function(e) {
                    e.preventDefault();
                    var target = $(this).data("tab");
                    $(".nav-tab").removeClass("nav-tab-active");
                    $(this).addClass("nav-tab-active");
                    $(".tab-content").hide();
                    $("#" + target).show();
                });

                // Continent blocking
                $(".block-continent").on("click", function() {
                    var continent = $(this).data("continent");
                    $.post(ajaxurl, {
                        action: "securepress_block_continent",
                        continent: continent,
                        nonce: "' . wp_create_nonce('securepress_block_continent') . '"
                    }, function(response) {
                        if (response.success) {
                            location.reload();
                        }
                    });
                });

                $(".unblock-continent").on("click", function() {
                    var continent = $(this).data("continent");
                    $.post(ajaxurl, {
                        action: "securepress_unblock_continent",
                        continent: continent,
                        nonce: "' . wp_create_nonce('securepress_unblock_continent') . '"
                    }, function(response) {
                        if (response.success) {
                            location.reload();
                        }
                    });
                });
            });
        ');
    }
    
    public function init() {
        $this->setup_event_monitoring();
        $this->load_log_buffer();
    }
    
    public function activate() {
        $this->generate_baseline();
        $this->schedule_cron_jobs();
        
        // Save site information
        if (!get_option('securepress_site_id')) {
            update_option('securepress_site_id', $this->site_id);
        }
        
        $this->log_event('system', 'SecurePress MSSP Client Activated', 'info', 2);
        $this->send_site_registration();
    }
    
    public function deactivate() {
        $this->unschedule_cron_jobs();
        $this->send_buffered_logs(); // Send any remaining logs
        $this->log_event('system', 'SecurePress MSSP Client Deactivated', 'warning', 3);
    }
    
    private function generate_site_id() {
        return 'site_' . substr(md5(get_site_url() . time()), 0, 12);
    }
    
    private function schedule_cron_jobs() {
        if (!wp_next_scheduled('securepress_send_logs')) {
            wp_schedule_event(time(), 'fiveminutes', 'securepress_send_logs');
        }
        if (!wp_next_scheduled('securepress_integrity_check')) {
            wp_schedule_event(time(), 'twicedaily', 'securepress_integrity_check');
        }
        if (!wp_next_scheduled('securepress_heartbeat')) {
            wp_schedule_event(time(), 'hourly', 'securepress_heartbeat');
        }
        
        // Add custom cron interval
        add_filter('cron_schedules', function($schedules) {
            $schedules['fiveminutes'] = array(
                'interval' => 300,
                'display' => 'Every 5 Minutes'
            );
            return $schedules;
        });
    }
    
    private function unschedule_cron_jobs() {
        wp_clear_scheduled_hook('securepress_send_logs');
        wp_clear_scheduled_hook('securepress_integrity_check');
        wp_clear_scheduled_hook('securepress_heartbeat');
    }
    
    private function setup_event_monitoring() {
        // Authentication Events
        add_action('wp_login', [$this, 'log_login']);
        add_action('wp_logout', [$this, 'log_logout']);
        add_action('wp_login_failed', [$this, 'log_failed_login']);
        
        // Administrative Events
        add_action('activated_plugin', [$this, 'log_plugin_activation']);
        add_action('deactivated_plugin', [$this, 'log_plugin_deactivation']);
        add_action('upgrader_process_complete', [$this, 'log_update'], 10, 2);
        
        // Content Events
        add_action('save_post', [$this, 'log_post_save']);
        add_action('delete_post', [$this, 'log_post_delete']);
        
        // User Management
        add_action('user_register', [$this, 'log_user_register']);
        add_action('delete_user', [$this, 'log_user_delete']);
        add_action('profile_update', [$this, 'log_profile_update']);
        
        // Critical Settings
        add_action('updated_option', [$this, 'log_critical_option_changes'], 10, 3);
        
        // File Upload Events
        add_action('wp_handle_upload', [$this, 'log_file_upload']);
        
        // API Events
        add_filter('rest_pre_dispatch', [$this, 'log_rest_api'], 10, 3);
        add_action('xmlrpc_call', [$this, 'log_xmlrpc']);
        
        // Theme/Template Events
        add_action('switch_theme', [$this, 'log_theme_switch']);
        
        // Comment Events (for spam detection)
        add_action('comment_post', [$this, 'log_comment']);
        add_action('wp_set_comment_status', [$this, 'log_comment_status'], 10, 2);
        
        // Add new monitoring hooks
        add_action('init', [$this, 'check_core_integrity']);
        add_action('init', [$this, 'monitor_database_changes']);
        add_action('init', [$this, 'check_suspicious_activity']);
        add_action('init', [$this, 'monitor_file_permissions']);
    }
    
    // Event Logging Methods
    public function log_login($user_login) {
        $user = get_user_by('login', $user_login);
        $this->log_event('auth', "Successful login: $user_login (Role: " . implode(',', $user->roles) . ")", 'info', 1);
        $this->reset_failed_login_count($this->get_client_ip());
    }
    
    public function log_logout() {
        $current_user = wp_get_current_user();
        $this->log_event('auth', "User logout: " . $current_user->user_login, 'info', 1);
    }
    
    public function log_failed_login($username) {
        $ip = $this->get_client_ip();
        $this->failed_logins[$ip] = ($this->failed_logins[$ip] ?? 0) + 1;
        
        $threat_score = min($this->failed_logins[$ip] * 2, 10);
        $this->log_event('auth', "Failed login attempt: $username (Attempt #{$this->failed_logins[$ip]})", 'warning', $threat_score, true);
        
        // Send immediate alert for multiple failures
        if ($this->failed_logins[$ip] >= 5) {
            $this->log_event('threat', "Brute force attack detected from IP: $ip", 'critical', 10, true);
        }
    }
    
    public function log_plugin_activation($plugin) {
        $this->log_event('admin', "Plugin activated: $plugin", 'warning', 4, true);
    }
    
    public function log_plugin_deactivation($plugin) {
        $this->log_event('admin', "Plugin deactivated: $plugin", 'warning', 4);
    }
    
    public function log_update($upgrader, $options) {
        if ($options['action'] === 'update') {
            $type = $options['type'];
            $message = "WordPress $type updated";
            if ($type === 'plugin' && isset($options['plugins'])) {
                $message .= ": " . implode(', ', $options['plugins']);
            } elseif ($type === 'theme' && isset($options['themes'])) {
                $message .= ": " . implode(', ', $options['themes']);
            }
            $this->log_event('admin', $message, 'info', 3, true);
        }
    }
    
    public function log_post_save($post_id) {
        $post = get_post($post_id);
        if ($post && !wp_is_post_revision($post_id) && $post->post_status === 'publish') {
            $this->log_event('content', "Post published: ID=$post_id, Title=" . substr($post->post_title, 0, 50), 'info', 1);
        }
    }
    
    public function log_post_delete($post_id) {
        $this->log_event('content', "Post deleted: ID=$post_id", 'warning', 3);
    }
    
    public function log_user_register($user_id) {
        $user = get_userdata($user_id);
        $this->log_event('user', "New user registered: " . $user->user_login . " (Role: " . implode(',', $user->roles) . ")", 'info', 2);
    }
    
    public function log_user_delete($user_id) {
        $user = get_userdata($user_id);
        $this->log_event('user', "User deleted: " . $user->user_login, 'warning', 5, true);
    }
    
    public function log_profile_update($user_id) {
        $user = get_userdata($user_id);
        $this->log_event('user', "Profile updated: " . $user->user_login, 'info', 1);
    }
    
    public function log_critical_option_changes($option_name, $old_value, $new_value) {
        $critical_options = [
            'active_plugins' => 8,
            'template' => 7,
            'stylesheet' => 7,
            'siteurl' => 9,
            'home' => 9,
            'admin_email' => 6,
            'users_can_register' => 5,
            'default_role' => 7,
            'blogname' => 3,
            'blogdescription' => 2
        ];
        
        if (array_key_exists($option_name, $critical_options)) {
            $threat_score = $critical_options[$option_name];
            $severity = $threat_score > 7 ? 'critical' : ($threat_score > 4 ? 'warning' : 'info');
            $send_immediate = $threat_score > 6;
            
            $this->log_event('config', "Critical option changed: $option_name", $severity, $threat_score, $send_immediate);
        }
    }
    
    public function log_file_upload($upload) {
        $file_type = wp_check_filetype($upload['file']);
        $threat_score = $this->assess_file_threat($file_type['ext']);
        
        $severity = $threat_score > 7 ? 'critical' : ($threat_score > 3 ? 'warning' : 'info');
        $this->log_event('file', "File uploaded: " . basename($upload['file']) . " (Type: {$file_type['ext']})", $severity, $threat_score, $threat_score > 7);
        
        return $upload;
    }
    
    public function log_rest_api($result, $server, $request) {
        $route = $request->get_route();
        $method = $request->get_method();
        
        // Log potentially dangerous API calls
        $sensitive_routes = ['/wp/v2/users', '/wp/v2/plugins', '/wp/v2/themes'];
        foreach ($sensitive_routes as $sensitive_route) {
            if (strpos($route, $sensitive_route) !== false) {
                $threat_score = ($method === 'POST' || $method === 'PUT' || $method === 'DELETE') ? 6 : 3;
                $this->log_event('api', "REST API call: $method $route", 'warning', $threat_score);
                break;
            }
        }
        
        return $result;
    }
    
    public function log_xmlrpc($method) {
        $threat_score = 5; // XML-RPC is often used in attacks
        $this->log_event('api', "XML-RPC call: $method", 'warning', $threat_score);
    }
    
    public function log_theme_switch($new_name) {
        $this->log_event('admin', "Theme switched to: $new_name", 'warning', 6, true);
    }
    
    public function log_comment($comment_id) {
        $comment = get_comment($comment_id);
        $threat_score = $this->assess_comment_threat($comment);
        
        if ($threat_score > 3) {
            $this->log_event('comment', "Suspicious comment posted: ID=$comment_id", 'warning', $threat_score);
        }
    }
    
    public function log_comment_status($comment_id, $status) {
        if ($status === 'spam') {
            $this->log_event('comment', "Comment marked as spam: ID=$comment_id", 'info', 2);
        }
    }
    
    // Core logging function
    private function log_event($category, $message, $severity = 'info', $threat_score = 0, $send_immediate = false) {
        $event = [
            'timestamp' => current_time('mysql'),
            'site_id' => $this->site_id,
            'site_url' => get_site_url(),
            'site_name' => get_option('blogname'),
            'category' => $category,
            'message' => $message,
            'severity' => $severity,
            'threat_score' => $threat_score,
            'ip_address' => $this->get_client_ip(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
            'user_id' => get_current_user_id(),
            'username' => wp_get_current_user()->user_login ?? 'Guest',
            'wp_version' => get_bloginfo('version'),
            'plugin_version' => SECUREPRESS_VERSION
        ];
        
        // Add to buffer
        $this->log_buffer[] = $event;
        
        // Also log locally as backup
        $this->log_locally($event);
        
        // Send immediately for critical events
        if ($send_immediate || $severity === 'critical' || count($this->log_buffer) >= SECUREPRESS_BUFFER_SIZE) {
            $this->send_buffered_logs();
        }
        
        // Save buffer to ensure persistence
        $this->save_log_buffer();
    }
    
    private function log_locally($event) {
        $log_entry = sprintf(
            "[%s] [%s] [%s] [Score:%d] [IP:%s] [User:%s] %s\n",
            $event['timestamp'],
            strtoupper($event['severity']),
            strtoupper($event['category']),
            $event['threat_score'],
            $event['ip_address'],
            $event['username'],
            $event['message']
        );
        
        file_put_contents(SECUREPRESS_LOCAL_LOG, $log_entry, FILE_APPEND | LOCK_EX);
    }
    
    public function send_buffered_logs() {
        if (empty($this->log_buffer) || empty($this->monitoring_server) || empty($this->api_key)) {
            return;
        }
        
        $payload = [
            'api_key' => $this->api_key,
            'events' => $this->log_buffer,
            'site_info' => $this->get_site_info()
        ];
        
        $response = $this->send_to_monitoring_server('/api/events', $payload);
        
        if ($response && $response['success']) {
            // Clear buffer on successful send
            $this->log_buffer = [];
            $this->save_log_buffer();
        } else {
            // Keep logs in buffer and try again later
            error_log('SecurePress: Failed to send logs to monitoring server');
        }
    }
    
    public function send_critical_logs() {
        $critical_logs = array_filter($this->log_buffer, function($event) {
            return $event['severity'] === 'critical' || $event['threat_score'] >= 8;
        });
        
        if (!empty($critical_logs)) {
            $this->send_buffered_logs();
        }
    }
    
    public function send_heartbeat() {
        if (empty($this->monitoring_server) || empty($this->api_key)) {
            return;
        }
        
        $payload = [
            'api_key' => $this->api_key,
            'site_id' => $this->site_id,
            'site_info' => $this->get_site_info(),
            'status' => 'online',
            'last_seen' => current_time('mysql')
        ];
        
        $this->send_to_monitoring_server('/api/heartbeat', $payload);
    }
    
    private function send_to_monitoring_server($endpoint, $data) {
        $url = rtrim($this->monitoring_server, '/') . $endpoint;
        
        $args = [
            'body' => json_encode($data),
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-Key' => $this->api_key
            ],
            'timeout' => 30,
            'method' => 'POST'
        ];
        
        $response = wp_remote_post($url, $args);
        
        if (is_wp_error($response)) {
            error_log('SecurePress API Error: ' . $response->get_error_message());
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        return json_decode($body, true);
    }
    
    private function get_site_info() {
        return [
            'site_id' => $this->site_id,
            'site_url' => get_site_url(),
            'site_name' => get_option('blogname'),
            'wp_version' => get_bloginfo('version'),
            'php_version' => PHP_VERSION,
            'active_theme' => get_template(),
            'active_plugins' => get_option('active_plugins'),
            'users_count' => count_users()['total_users'],
            'posts_count' => wp_count_posts()->publish,
            'last_update' => current_time('mysql')
        ];
    }
    
    private function send_site_registration() {
        if (empty($this->monitoring_server) || empty($this->api_key)) {
            return;
        }
        
        $payload = [
            'api_key' => $this->api_key,
            'action' => 'register_site',
            'site_info' => $this->get_site_info()
        ];
        
        $this->send_to_monitoring_server('/api/sites', $payload);
    }
    
    // File integrity checking
    public function generate_baseline() {
        $critical_paths = [
            ABSPATH . 'wp-admin/index.php',
            ABSPATH . 'wp-login.php',
            ABSPATH . 'wp-config.php',
            get_template_directory() . '/functions.php',
            get_template_directory() . '/index.php'
        ];
        
        $baseline = [];
        foreach ($critical_paths as $file) {
            if (file_exists($file)) {
                $baseline[$file] = [
                    'hash' => hash_file('sha256', $file),
                    'size' => filesize($file),
                    'modified' => filemtime($file)
                ];
            }
        }
        
        update_option('securepress_baseline', $baseline);
        $this->log_event('system', 'File integrity baseline updated - ' . count($baseline) . ' critical files monitored', 'info', 2);
    }
    
    public function check_integrity() {
        $baseline = get_option('securepress_baseline', []);
        
        foreach ($baseline as $file => $info) {
            if (!file_exists($file)) {
                $this->log_event('threat', "CRITICAL FILE DELETED: $file", 'critical', 10, true);
            } else {
                $current_hash = hash_file('sha256', $file);
                if ($current_hash !== $info['hash']) {
                    $this->log_event('threat', "CRITICAL FILE MODIFIED: $file", 'critical', 9, true);
                }
            }
        }
    }
    
    // Utility functions
    private function get_client_ip() {
        $ip_headers = [
            'HTTP_CF_CONNECTING_IP',     // Cloudflare
            'HTTP_CLIENT_IP',            // Proxy
            'HTTP_X_FORWARDED_FOR',      // Load balancer/proxy
            'HTTP_X_FORWARDED',          // Proxy
            'HTTP_X_CLUSTER_CLIENT_IP',  // Cluster
            'HTTP_FORWARDED_FOR',        // Proxy
            'HTTP_FORWARDED',            // Proxy
            'REMOTE_ADDR'                // Standard
        ];
        
        foreach ($ip_headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ips = explode(',', $_SERVER[$header]);
                $ip = trim($ips[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    private function assess_file_threat($extension) {
        $dangerous_extensions = [
            'php' => 9, 'php3' => 9, 'php4' => 9, 'php5' => 9, 'phtml' => 9,
            'exe' => 10, 'bat' => 8, 'cmd' => 8, 'com' => 8, 'scr' => 8,
            'js' => 4, 'vbs' => 7, 'jar' => 6, 'py' => 5, 'pl' => 5
        ];
        
        return $dangerous_extensions[strtolower($extension)] ?? 1;
    }
    
    private function assess_comment_threat($comment) {
        $threat_score = 0;
        $content = strtolower($comment->comment_content);
        
        // Check for suspicious patterns
        $suspicious_patterns = [
            'viagra' => 3, 'casino' => 3, 'poker' => 3, 'loan' => 2,
            '<script' => 8, 'javascript:' => 8, 'eval(' => 9,
            'union select' => 9, 'drop table' => 10, '../' => 6
        ];
        
        foreach ($suspicious_patterns as $pattern => $score) {
            if (strpos($content, $pattern) !== false) {
                $threat_score = max($threat_score, $score);
            }
        }
        
        // Check for excessive links
        if (substr_count($content, 'http') > 3) {
            $threat_score = max($threat_score, 5);
        }
        
        return $threat_score;
    }
    
    private function reset_failed_login_count($ip) {
        unset($this->failed_logins[$ip]);
    }
    
    private function load_log_buffer() {
        $this->log_buffer = get_option('securepress_log_buffer', []);
    }
    
    private function save_log_buffer() {
        update_option('securepress_log_buffer', $this->log_buffer);
    }
    
    // Admin interface
    public function add_admin_menu() {
        add_options_page(
            'SecurePress Settings',
            'SecurePress',
            'manage_options',
            'securepress-mssp',
            [$this, 'render_admin_page']
        );
    }
    
    public function render_admin_page() {
        ?>
        <div class="wrap">
            <h1>SecurePress Settings</h1>
            
            <h2 class="nav-tab-wrapper">
                <a href="#" class="nav-tab nav-tab-active" data-tab="settings">Settings</a>
                <a href="#" class="nav-tab" data-tab="geo-blocking">Geo-Blocking</a>
                <a href="#" class="nav-tab" data-tab="monitoring">Monitoring</a>
            </h2>

            <div id="settings" class="tab-content">
                <form method="post" action="options.php">
                    <?php
                    settings_fields('securepress_options');
                    do_settings_sections('securepress_options');
                    ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row">API Key</th>
                            <td>
                                <input type="text" name="securepress_options[api_key]" value="<?php echo esc_attr($this->options['api_key']); ?>" class="regular-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Server URL</th>
                            <td>
                                <input type="url" name="securepress_options[server_url]" value="<?php echo esc_url($this->options['server_url']); ?>" class="regular-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Send Interval (seconds)</th>
                            <td>
                                <input type="number" name="securepress_options[send_interval]" value="<?php echo esc_attr($this->options['send_interval']); ?>" min="60" class="small-text">
                            </td>
                        </tr>
                    </table>
                    <?php submit_button(); ?>
                </form>
            </div>

            <div id="geo-blocking" class="tab-content" style="display: none;">
                <h2>Geo-Blocking Configuration</h2>
                <div class="card">
                    <h3>Continent Controls</h3>
                    <p>
                        <button class="button block-continent" data-continent="asia">Block Asia</button>
                        <button class="button block-continent" data-continent="europe">Block Europe</button>
                        <button class="button block-continent" data-continent="africa">Block Africa</button>
                        <button class="button block-continent" data-continent="north-america">Block North America</button>
                        <button class="button block-continent" data-continent="south-america">Block South America</button>
                        <button class="button block-continent" data-continent="oceania">Block Oceania</button>
                    </p>
                    <p>
                        <button class="button unblock-continent" data-continent="asia">Unblock Asia</button>
                        <button class="button unblock-continent" data-continent="europe">Unblock Europe</button>
                        <button class="button unblock-continent" data-continent="africa">Unblock Africa</button>
                        <button class="button unblock-continent" data-continent="north-america">Unblock North America</button>
                        <button class="button unblock-continent" data-continent="south-america">Unblock South America</button>
                        <button class="button unblock-continent" data-continent="oceania">Unblock Oceania</button>
                    </p>
                </div>
                <div class="card">
                    <h3>World Map</h3>
                    <p>Click on countries to block/unblock them. Green countries are allowed, red countries are blocked.</p>
                    <div id="world-map" style="width: 100%; height: 500px;"></div>
                </div>
            </div>

            <div id="monitoring" class="tab-content" style="display: none;">
                <div class="card">
                    <h2>Enhanced Security Monitoring</h2>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Feature</th>
                                <th>Status</th>
                                <th>Last Check</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Core File Integrity</td>
                                <td><?php echo $this->check_core_integrity_status(); ?></td>
                                <td><?php echo get_option('securepress_last_core_check', 'Never'); ?></td>
                            </tr>
                            <tr>
                                <td>Database Monitoring</td>
                                <td>Active</td>
                                <td>Real-time</td>
                            </tr>
                            <tr>
                                <td>File Permissions</td>
                                <td><?php echo $this->check_file_permissions_status(); ?></td>
                                <td><?php echo get_option('securepress_last_permissions_check', 'Never'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

    // New monitoring methods
    public function check_core_integrity() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $core_files = [
            'wp-login.php',
            'wp-admin/index.php',
            'wp-admin/admin.php',
            'wp-includes/version.php'
        ];

        foreach ($core_files as $file) {
            $file_path = ABSPATH . $file;
            if (file_exists($file_path)) {
                $current_hash = hash_file('sha256', $file_path);
                $expected_hash = $this->get_core_file_hash($file);
                
                if ($current_hash !== $expected_hash) {
                    $this->log_event('threat', "Core file modification detected: $file", 'critical', 9, true);
                }
            }
        }
    }

    public function monitor_database_changes() {
        global $wpdb;
        
        // Monitor for suspicious database queries
        add_filter('query', function($query) {
            $suspicious_patterns = [
                'UNION SELECT',
                'INTO OUTFILE',
                'LOAD_FILE',
                '--',
                '/*',
                'DROP TABLE',
                'TRUNCATE TABLE'
            ];
            
            foreach ($suspicious_patterns as $pattern) {
                if (stripos($query, $pattern) !== false) {
                    $this->log_event('threat', "Suspicious database query detected: " . substr($query, 0, 100), 'critical', 10, true);
                    break;
                }
            }
            
            return $query;
        });
    }

    public function check_suspicious_activity() {
        // Check for suspicious user agents
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $suspicious_agents = [
            'sqlmap',
            'nikto',
            'nmap',
            'acunetix',
            'nessus',
            'wpscan'
        ];
        
        foreach ($suspicious_agents as $agent) {
            if (stripos($user_agent, $agent) !== false) {
                $this->log_event('threat', "Suspicious user agent detected: $user_agent", 'critical', 8, true);
                break;
            }
        }
        
        // Check for suspicious request patterns
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $suspicious_patterns = [
            '/wp-config.php',
            '/wp-content/plugins/',
            '/wp-content/themes/',
            '/wp-admin/install.php',
            '/wp-admin/setup-config.php'
        ];
        
        foreach ($suspicious_patterns as $pattern) {
            if (stripos($request_uri, $pattern) !== false) {
                $this->log_event('threat', "Suspicious request pattern detected: $request_uri", 'warning', 7);
                break;
            }
        }
    }

    public function monitor_file_permissions() {
        $critical_paths = [
            ABSPATH . 'wp-config.php',
            ABSPATH . 'wp-content',
            ABSPATH . 'wp-admin',
            ABSPATH . 'wp-includes'
        ];
        
        foreach ($critical_paths as $path) {
            if (file_exists($path)) {
                $perms = fileperms($path);
                $perms = substr(sprintf('%o', $perms), -4);
                
                // Check for overly permissive settings
                if ($perms == '0777' || $perms == '0666') {
                    $this->log_event('threat', "Overly permissive file permissions detected: $path ($perms)", 'critical', 8, true);
                }
            }
        }
    }

    private function get_core_file_hash($file) {
        // This would typically be populated from a secure source
        // For demonstration, we'll use a placeholder
        $core_hashes = [
            'wp-login.php' => 'placeholder_hash_1',
            'wp-admin/index.php' => 'placeholder_hash_2',
            'wp-admin/admin.php' => 'placeholder_hash_3',
            'wp-includes/version.php' => 'placeholder_hash_4'
        ];
        
        return $core_hashes[$file] ?? '';
    }

    private function check_core_integrity_status() {
        $last_check = get_option('securepress_last_core_check');
        if (!$last_check) {
            return '<span class="status-warning">Not Checked</span>';
        }
        
        $issues = get_option('securepress_core_integrity_issues', 0);
        if ($issues > 0) {
            return '<span class="status-critical">Issues Found</span>';
        }
        
        return '<span class="status-ok">OK</span>';
    }

    private function check_file_permissions_status() {
        $last_check = get_option('securepress_last_permissions_check');
        if (!$last_check) {
            return '<span class="status-warning">Not Checked</span>';
        }
        
        $issues = get_option('securepress_permissions_issues', 0);
        if ($issues > 0) {
            return '<span class="status-critical">Issues Found</span>';
        }
        
        return '<span class="status-ok">OK</span>';
    }

    // Add new methods for geo-blocking
    private function get_country_status() {
        $blocked_countries = get_option('securepress_blocked_countries', []);
        $countries = [];
        
        // Get all country codes
        $country_codes = $this->get_country_codes();
        
        foreach ($country_codes as $code) {
            $countries[$code] = in_array($code, $blocked_countries) ? 1 : 0;
        }
        
        return $countries;
    }
    
    private function get_country_codes() {
        return [
            'AF', 'AX', 'AL', 'DZ', 'AS', 'AD', 'AO', 'AI', 'AQ', 'AG', 'AR', 'AM', 'AW', 'AU', 'AT', 'AZ',
            'BS', 'BH', 'BD', 'BB', 'BY', 'BE', 'BZ', 'BJ', 'BM', 'BT', 'BO', 'BA', 'BW', 'BV', 'BR', 'IO',
            'BN', 'BG', 'BF', 'BI', 'KH', 'CM', 'CA', 'CV', 'KY', 'CF', 'TD', 'CL', 'CN', 'CX', 'CC', 'CO',
            'KM', 'CG', 'CD', 'CK', 'CR', 'CI', 'HR', 'CU', 'CY', 'CZ', 'DK', 'DJ', 'DM', 'DO', 'EC', 'EG',
            'SV', 'GQ', 'ER', 'EE', 'ET', 'FK', 'FO', 'FJ', 'FI', 'FR', 'GF', 'PF', 'TF', 'GA', 'GM', 'GE',
            'DE', 'GH', 'GI', 'GR', 'GL', 'GD', 'GP', 'GU', 'GT', 'GG', 'GN', 'GW', 'GY', 'HT', 'HM', 'VA',
            'HN', 'HK', 'HU', 'IS', 'IN', 'ID', 'IR', 'IQ', 'IE', 'IM', 'IL', 'IT', 'JM', 'JP', 'JE', 'JO',
            'KZ', 'KE', 'KI', 'KP', 'KR', 'KW', 'KG', 'LA', 'LV', 'LB', 'LS', 'LR', 'LY', 'LI', 'LT', 'LU',
            'MO', 'MK', 'MG', 'MW', 'MY', 'MV', 'ML', 'MT', 'MH', 'MQ', 'MR', 'MU', 'YT', 'MX', 'FM', 'MD',
            'MC', 'MN', 'ME', 'MS', 'MA', 'MZ', 'MM', 'NA', 'NR', 'NP', 'NL', 'AN', 'NC', 'NZ', 'NI', 'NE',
            'NG', 'NU', 'NF', 'MP', 'NO', 'OM', 'PK', 'PW', 'PS', 'PA', 'PG', 'PY', 'PE', 'PH', 'PN', 'PL',
            'PT', 'PR', 'QA', 'RE', 'RO', 'RU', 'RW', 'BL', 'SH', 'KN', 'LC', 'MF', 'PM', 'VC', 'WS', 'SM',
            'ST', 'SA', 'SN', 'RS', 'SC', 'SL', 'SG', 'SK', 'SI', 'SB', 'SO', 'ZA', 'GS', 'ES', 'LK', 'SD',
            'SR', 'SJ', 'SZ', 'SE', 'CH', 'SY', 'TW', 'TJ', 'TZ', 'TH', 'TL', 'TG', 'TK', 'TO', 'TT', 'TN',
            'TR', 'TM', 'TC', 'TV', 'UG', 'UA', 'AE', 'GB', 'US', 'UM', 'UY', 'UZ', 'VU', 'VE', 'VN', 'VG',
            'VI', 'WF', 'EH', 'YE', 'ZM', 'ZW'
        ];
    }
    
    public function ajax_update_country_status() {
        check_ajax_referer('securepress_update_country', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $country = sanitize_text_field($_POST['country']);
        $blocked = intval($_POST['blocked']);
        
        $blocked_countries = get_option('securepress_blocked_countries', []);
        
        if ($blocked === 1) {
            if (!in_array($country, $blocked_countries)) {
                $blocked_countries[] = $country;
            }
        } else {
            $blocked_countries = array_diff($blocked_countries, [$country]);
        }
        
        update_option('securepress_blocked_countries', $blocked_countries);
        wp_send_json_success();
    }
    
    public function ajax_block_continent() {
        check_ajax_referer('securepress_block_continent', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $continent = sanitize_text_field($_POST['continent']);
        
        if (!isset($this->continent_countries[$continent])) {
            wp_send_json_error('Invalid continent');
        }
        
        $blocked_countries = get_option('securepress_blocked_countries', []);
        $blocked_countries = array_unique(array_merge($blocked_countries, $this->continent_countries[$continent]));
        update_option('securepress_blocked_countries', $blocked_countries);
        
        wp_send_json_success();
    }
    
    public function ajax_unblock_continent() {
        check_ajax_referer('securepress_unblock_continent', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $continent = sanitize_text_field($_POST['continent']);
        
        if (!isset($this->continent_countries[$continent])) {
            wp_send_json_error('Invalid continent');
        }
        
        $blocked_countries = get_option('securepress_blocked_countries', []);
        $blocked_countries = array_diff($blocked_countries, $this->continent_countries[$continent]);
        update_option('securepress_blocked_countries', $blocked_countries);
        
        wp_send_json_success();
    }
}

// Initialize the plugin
SecurePressClient::get_instance();